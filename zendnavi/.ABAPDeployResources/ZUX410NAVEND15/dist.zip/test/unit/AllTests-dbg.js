sap.ui.define([
	"zendnavi/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
