sap.ui.define([
	"zdynamicpage15/test/unit/controller/App.controller"
], function () {
	"use strict";
});
