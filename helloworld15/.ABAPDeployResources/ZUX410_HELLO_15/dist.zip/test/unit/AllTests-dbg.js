sap.ui.define([
	"student15sap.training./helloworld15/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
